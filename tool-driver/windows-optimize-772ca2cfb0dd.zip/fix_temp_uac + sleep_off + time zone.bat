@echo off
:: [PHAN 1] KIEM TRA QUYEN ADMIN
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    goto UACPrompt
) else ( goto START )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    exit /B

:START
chcp 65001 >nul
title CÔNG CỤ TỐI ƯU HỆ THỐNG
color 06
cls

echo ======================================================================
echo  HỆ THỐNG TỰ ĐỘNG CẤU HÌNH WINDOWS
echo ======================================================================
echo.

:: --- [1] TEMP & UAC ---
echo [1] THIẾT LẬP HỆ THỐNG VÀ QUYỀN TRUY CẬP
echo     - Đang cấp quyền truy cập đầy đủ cho thư mục Temp...
icacls "C:\Windows\Temp" /grant:r "Everyone":(OI)(CI)F /T >nul 
echo     - Đang cấu hình tắt thông báo kiểm soát người dùng (UAC)...
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 0 /f >nul
echo     =^> KẾT LUẬN: HOÀN TẤT
echo.

:: --- [2] POWER SETTINGS ---
echo [2] TỐI ƯU HÓA QUẢN LÝ ĐIỆN NĂNG
powercfg /SETACVALUEINDEX SCHEME_CURRENT SUB_VIDEO VIDEOIDLE 1800 >nul 2>&1
powercfg /SETDCVALUEINDEX SCHEME_CURRENT SUB_VIDEO VIDEOIDLE 1800 >nul 2>&1
powercfg /SETACVALUEINDEX SCHEME_CURRENT SUB_SLEEP standbyidle 3600 >nul 2>&1
powercfg /SETDCVALUEINDEX SCHEME_CURRENT SUB_SLEEP standbyidle 3600 >nul 2>&1
powercfg /SETACTIVE SCHEME_CURRENT >nul 2>&1
echo     - Màn hình         : 30 phút
echo     - Chế độ Sleep     : 60 phút
echo     =^> KẾT LUẬN: HOÀN TẤT
echo.

:: --- [3] DONG BO THOI GIAN ---
echo [3] CẤU HÌNH ^& ĐỒNG BỘ THỜI GIAN THÔNG MINH
echo [*] Bước 1: Đang tắt dịch vụ Windows Time (w32time)...
net stop w32time >nul 2>&1

echo [*] Bước 2: Đang làm sạch ^& đăng ký lại bộ đếm hệ thống...
w32tm /unregister >nul 2>&1
w32tm /register >nul 2>&1

echo [*] Bước 3: Đang khởi động lại dịch vụ hệ thống...
net start w32time >nul 2>&1

echo [*] Bước 4: Đang kết nối tới máy chủ time.windows.com...
w32tm /config /manualpeerlist:"time.windows.com" /syncfromflags:manual /reliable:YES /update >nul
w32tm /resync /force >nul 2>&1

if %errorLevel% == 0 (
    echo [OK] Đã đồng bộ THÀNH CÔNG từ time.windows.com.
) else (
    echo [!] Cảnh báo: time.windows.com thất bại.
    echo [*] Đang chuyển hướng sang máy chủ dự phòng: time.nist.gov...
    
    w32tm /config /manualpeerlist:"time.nist.gov" /syncfromflags:manual /reliable:YES /update >nul
    w32tm /resync /force >nul 2>&1
    
    if %errorLevel% == 0 (
        echo [OK] Đã đồng bộ THÀNH CÔNG từ time.nist.gov.
    ) else (
        echo [X] LỖI: Cả hai máy chủ đều không phản hồi. Vui lòng kiểm tra Internet.
    )
)

echo.
echo ======================================================================
echo  HOÀN TẤT TẤT CẢ CÁC TIẾN TRÌNH.
echo ======================================================================
echo.
echo Bấm phím bất kỳ để thoát...
pause > nul
exit
